"""Public API for the manage_externals library
"""

from manic import checkout
from manic.utils import printlog

__all__ = [
    'checkout', 'printlog',
]
